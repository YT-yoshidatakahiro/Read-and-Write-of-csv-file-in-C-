﻿using System;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace kadai2_1
{

    public partial class DataIO : Form
    {

        public DataIO()
        {
            InitializeComponent();

            MinimizeBox = false;

            MaximizeBox = false;
        }

        /// <summary>
        ///iniファイル読み込み設定
        /// </summary>
        [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileStringW", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern uint GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, uint nSize, string lpFileName);

        string fln1 = @"./kadaisetup.ini";

        private void DataIO_Load(object sender, EventArgs e)
        {
            btnWrite.Enabled = false;

            if (!(File.Exists(fln1)))
            {
                MessageBox.Show("iniファイルが見つかりません。"+
                            "所定場所:" + System.IO.Directory.GetCurrentDirectory());
                btnRead.Enabled = false;
                btnWrite.Enabled = false;

            }
            else
            {
                btnRead.Enabled = true;
            }
        }

        /// <summary>
        ///ファイルの存在の有無：存在しない場合，csvファイル作成し，データ入力
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRead_Click(object sender, EventArgs e)
        {
            try
            {
                //読み込み用のファイル指定
                int capacitySize = 256;

                StringBuilder sb = new StringBuilder(capacitySize);

                GetPrivateProfileString("pathdata", "pn1", "", sb, Convert.ToUInt32(sb.Capacity), fln1);

                string DBpath1;

                DBpath1 = @sb.ToString();

                //csvからgrid dataviewへ：gridの初期化→入力
                grvTable.Rows.Clear();

                StreamReader DB_R1 = new StreamReader(DBpath1);

　              int i = 1;

                while (DB_R1.EndOfStream == false)
                {
                    string DB_R3 = DB_R1.ReadLine();

                    string DB_R4 = i + "," + DB_R3.Trim('\"');

                    string[] DB_R5 = DB_R4.Split(',');

                    grvTable.Rows.Add(DB_R5);

                    i++;
                }
                DB_R1.Close();



                //griddataに行番号を入力
                for (int j = 0; j < grvTable.Rows.Count - 1; j++)
                {
                    grvTable.Rows[j].HeaderCell.Value = (j + 1).ToString();
                }

                btnWrite.Enabled = true;

            }
            catch (Exception)
            {
                MessageBox.Show("読み込み用のファイルを指定できません", "要確認");
            }

        }

        /// <summary>
        /// gridデータからCSVファイルへ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnWrite_Click(object sender, EventArgs e)
        {
            //書き込み用のファイル指定
            int capacitySize = 256;

            StringBuilder sb = new StringBuilder(capacitySize);

            GetPrivateProfileString("pathdata", "pn2", "", sb, Convert.ToUInt32(sb.Capacity), fln1);

            string DBpath2;

            DBpath2 = @sb.ToString();

            //iniファイルが読み込めない場合
            if (DBpath2.Equals(""))
            {
                MessageBox.Show("書き込み用のファイルを指定できません","要確認");
                btnWrite.Enabled = false;

                return;
            }

            //iniファイルが読み込める場合
            else
            {
                try
                {
                    // 書き込み用CSVファイルの作成と既存ファイルの初期化
                    StreamWriter DB_W1 = new StreamWriter(DBpath2);

                    for (int i = 0; i < grvTable.Rows.Count; i++)
                    {
                        string DB_W2 = Convert.ToString(grvTable[0, i].Value) + Convert.ToString(grvTable[1, i].Value) +

                            Convert.ToString(grvTable[2, i].Value) + Convert.ToString(grvTable[3, i].Value) + Convert.ToString(grvTable[4, i].Value);

                        DB_W1.WriteLine(DB_W2);
                    }
                    DB_W1.Close();

                    MessageBox.Show("書き込み完了\n" + System.IO.Directory.GetCurrentDirectory() + DBpath2, "書込完了");
                    btnWrite.Enabled = false;

                }

                //テータの出力と例外処理
                catch (IOException)
                {
                    MessageBox.Show("書き込めません", "要確認");
                    btnWrite.Enabled = false;
                }

            }

        }

         /// <summary>
         /// グリッドへのデータ表示画面
         /// </summary>
         /// <param name="sender"></param>
         /// <param name="e"></param>
         private void gvTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }


    }
}



